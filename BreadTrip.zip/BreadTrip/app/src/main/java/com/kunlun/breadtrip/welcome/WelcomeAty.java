package com.kunlun.breadtrip.welcome;

import com.kunlun.breadtrip.R;
import com.kunlun.breadtrip.base.BaseActivity;

/**
 * Created by dllo on 16/5/11.
 */
public class WelcomeAty extends BaseActivity {
    @Override
    protected int getLayout() {
        return R.layout.activity_welcome;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
