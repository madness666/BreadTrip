package com.kunlun.breadtrip.cityhunter;

import android.view.View;

import com.kunlun.breadtrip.R;
import com.kunlun.breadtrip.base.BaseFragment;

/**
 * Created by dllo on 16/5/10.
 */
public class CityHunterFragment extends BaseFragment {

    @Override
    public int initLayout() {
        return R.layout.fragment_cityhunter;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
