package com.kunlun.breadtrip.personal;

import android.view.View;

import com.kunlun.breadtrip.R;
import com.kunlun.breadtrip.base.BaseFragment;

/**
 * Created by dllo on 16/5/10.
 */
public class PersonalFragment extends BaseFragment {

    @Override
    public int initLayout() {
        return R.layout.fragment_personal;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
